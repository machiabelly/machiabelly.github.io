(self["webpackChunk_polygonjs_polygonjs"] = self["webpackChunk_polygonjs_polygonjs"] || []).push([[225],{

/***/ 75245:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B7": () => (/* binding */ gsapTimeline),
/* harmony export */   "g5": () => (/* binding */ GSAP_FACTORY),
/* harmony export */   "hD": () => (/* binding */ gsapLib)
/* harmony export */ });
const GSAP_FACTORY = {
    gsap: undefined,
    timeline: (vars) => {
        return undefined;
    },
};
function gsapTimeline(vars) {
    return GSAP_FACTORY.timeline(vars);
    // return gsap.timeline(vars);
}
function gsapLib() {
    return GSAP_FACTORY.gsap;
}



/***/ }),

/***/ 83220:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ ModuleName)
/* harmony export */ });
var ModuleName;
(function (ModuleName) {
    ModuleName["CAD"] = "CAD";
    ModuleName["CSG"] = "CSG";
    ModuleName["GSAP"] = "GSAP";
    ModuleName["PBR"] = "PBR";
    ModuleName["POLY_ANIM"] = "POLY_ANIM";
    ModuleName["POLY_GL"] = "POLY_GL";
    ModuleName["POLY_JS"] = "POLY_JS";
    ModuleName["POLY_OBJ"] = "POLY_OBJ";
    ModuleName["POLY_SOP"] = "POLY_SOP";
    ModuleName["QUAD"] = "QUAD";
    ModuleName["SDF"] = "SDF";
    ModuleName["TET"] = "TET";
})(ModuleName || (ModuleName = {}));


/***/ }),

/***/ 36826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "w": () => (/* binding */ GSAPModule)
});

// EXTERNAL MODULE: ./src/core/thirdParty/gsap/gsapFactory.ts
var gsapFactory = __webpack_require__(75245);
// EXTERNAL MODULE: ./node_modules/gsap/index.js + 2 modules
var gsap = __webpack_require__(66358);
;// CONCATENATED MODULE: ./src/core/thirdParty/gsap/gsapModule.ts


function onGsapModuleRegister(poly) {
    gsapFactory/* GSAP_FACTORY.gsap */.g5.gsap = gsap/* gsap */.p8;
    gsapFactory/* GSAP_FACTORY.timeline */.g5.timeline = (vars) => {
        return gsap/* gsap.timeline */.p8.timeline(vars);
    };
}

// EXTERNAL MODULE: ./src/engine/poly/registers/modules/Common.ts
var Common = __webpack_require__(83220);
;// CONCATENATED MODULE: ./src/engine/poly/registers/modules/entryPoints/GSAP.ts


const GSAPModule = {
    moduleName: Common/* ModuleName.GSAP */.r.GSAP,
    // module: cadModule,
    onRegister: onGsapModuleRegister,
};



/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ var __webpack_exports__ = (__webpack_exec__(36826));
/******/ var __webpack_exports__GSAPModule = __webpack_exports__.w;
/******/ export { __webpack_exports__GSAPModule as GSAPModule };
/******/ }
])
//# sourceMappingURL=GSAP.js.map